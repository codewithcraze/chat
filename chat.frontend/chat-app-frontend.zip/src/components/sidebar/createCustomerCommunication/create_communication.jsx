export default function CreateCustomerCommunication() {
    return (
        <>
            Create Conversation
        </>

    )
}