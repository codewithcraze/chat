import CreateCustomerCommunication from './create_communication.jsx';

export {
    CreateCustomerCommunication
}